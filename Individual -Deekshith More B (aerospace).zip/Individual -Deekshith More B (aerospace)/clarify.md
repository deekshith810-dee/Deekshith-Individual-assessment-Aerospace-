# Clarifications – Compliance Copilot

## Open Questions

- Which compliance framework is required?
- How detailed should traceability be?
- What rules define compliance validation?

---

## Assumptions

- Validation uses rule-based engine
- Traceability is requirement-centered
- Reports are generated on-demand

---

## Risks

- Missing rule definitions
- Incorrect traceability links
- Audit inconsistencies